document.write(`

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Best Website Designing and Digital Marketing Services in Noida, Delhi, NCR</title>
<link rel="icon" href="assets/img/favicon.ico" type="image/x-icon">

 <!-- CSS only -->
 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
 <!-- Font Awesome 6 -->
 <link rel="stylesheet" href="assets/css/fontawesome.min.css">
 <link rel="stylesheet" href="assets/css/jquery.fancybox.min.css">
 <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
 <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
 
 <!-- style -->
 <link rel="stylesheet" href="assets/css/style.css">
 <!-- responsive -->
 <link rel="stylesheet" href="assets/css/responsive.css">
 <!-- color -->
 <link rel="stylesheet" href="assets/css/color.css">
 <!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-NJSJBP8');</script>
<!-- End Google Tag Manager -->
 <header id="stickyHeader">
 <div class="container">
   <div class="nav">
     <div class="logo">
       <a href="#">
         <img alt="logo" src="assets/img/logo-b.png" style="width:10rem"/>
       </a>
       <div class="line"></div>
       <ul>
        
         
       </ul>
     </div>
   <div class="row desk-v">
                <div class="col-6">
                <a href="https://wa.me/+917607770184" target="_blank">
         <img src="./assets/img/whtas-wpp.png">
     </a>
                </div>
                <div class="col-6">
                    <a href="tel:+7607770184">
         <img src="./assets/img/call-us.png">
     </a>
                </div>
            </div>
   </div>
 </div>
</header>

`);