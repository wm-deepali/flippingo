document.write(`
<footer style="background-image: url(assets/img/footer.jpg);">
      <div class="container">
          <div class="book-free">
            <img alt="paper-plan" src="assets/img/paper-plan.png">
              <h2>Book a Free Consultation</h2>
              <p>We'll focus on your product goals, context and technology needs to make sure we can add</p>
              <a href="#" class="batton" data-bs-toggle="modal" data-bs-target="#formmodal">Request a Quote</a>
              <ul>
                  <li><a href="https://www.facebook.com/ Flippingoweb" target="blank"><i class="fa-brands fa-facebook-f"></i>facebook</a></li>
                  <li><a href="https://www.linkedin.com/company/ Flippingo/"><i class="fa-brands fa-linkedin" target="blank"></i>linkedin</a></li>
                  <li><a href="https://twitter.com/ Flippingoweb"><i class="fa-brands fa-twitter" target="blank"></i>twitter</a></li>
                  <li><a href="https://www.instagram.com/ Flippingoweb/"><i class="fa-brands fa-instagram" target="blank"></i>Instagram</a></li>
              </ul>
          </div>©  2022 Web Mingo IT Solutions. All Rights Reserved
          <p class="footer">2023 © Copyright Web Mingo IT Solutions. All Rights Reserved </p>
      </div>
  </footer>

  <!-- Back to top button -->
    <a id="button"></a>
  <!-- Back to top button end -->
  <a href="" class="float x" target="_blank">
<img src="./assets/img/icons8-whatsapp.svg" />
</a>

  <!-- jQuery -->
  <script src="assets/js/jquery-3.6.0.min.js"></script>
  <!-- Bootstrap Js -->
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/jquery.fancybox.min.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script src="assets/js/custom.js"></script>


`);