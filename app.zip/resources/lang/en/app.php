<?php

return [
    'heading' => 'Heading',
    'paragraphText' => 'You can edit this paragraph by clicking here.',
    'npsQuestion' => 'On a scale from 0-10, how likely are you to recommend our company to a friend or colleague?',
    'notAtAllLikely' => 'Not at all likely',
    'extremelyLikely' => 'Extremely likely',
    'submit' => 'Submit',
    'thankYou' => 'Thank you for your feedback!',
];
